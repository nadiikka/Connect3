package com.connect3.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
