package com.codegarden.Connect3;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
